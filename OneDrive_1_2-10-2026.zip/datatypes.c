#include <stdio.h>
int main()
{
    int a = 10;
    float b = 3.14;
    double c = 12.3456789;
    char d = 'X';
    printf("integer value:%d\n", a);
    printf("float value:%.2f\n", b);
    printf("double value:%.9f\n", d);
    printf("character value:%c\n", d);
    return 0;
}